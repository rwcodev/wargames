
This webpage is created to allow LOGIN and REGISTER options for the user and a download section 
for the files required (like 3d printed parts, the gerbers for the creation of the PCB etc.)
to build the equipment; the tripodes, the AR-AR rifle (AR15 rifle with Augmented Reality), and 
the Orbital Weapon. 
(More details about this project in this video (iin spanish) made by me: 
https://youtu.be/tYVZKfluKMQ?si=6Tbh31JBQ4gy-pQy )
