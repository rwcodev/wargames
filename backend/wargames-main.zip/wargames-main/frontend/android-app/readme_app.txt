This app works with unreal engine, the geometry of the enemies is already loaded in it
and only will receive the localization of the enemies (characters) and the time
when they have to be appears for the player.