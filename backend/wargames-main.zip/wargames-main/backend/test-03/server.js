//server.js

const express = require("express"); //importing the "express" package
const http = require("http"); //importing the built-in "http" package

const app = express()
const server = http.createServer(app)
const PORT = 3200

server.listen(PORT);
console.log("Server listening on port " + PORT + "!");

app.get('/',(req, res) => {
  res.send("Telemetry data sended(-target.properties(x(n),y(n),x(n))¡¡")
})