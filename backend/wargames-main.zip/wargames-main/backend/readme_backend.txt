The backend is made it with nodeJS, interacts with the app and the tripodes,
receives the ubication of the players and also determinates the location of 
the enemies based in the telemetry obtained from the tripodes.

To maintain a low latency in the comunication between the backend and the users the data transfers
will consists only in telemetry data(no images, no video), all the animations of the enemies 
will be rendered on the app.


Los ENDPOINTS necesarios son los siguientes; 
LOGIN:  
REGISTER:
RECEIVE_DATA: El BACKEND recibira la data que consiste en la telemetria,
por ejemplo (x(n), y(n), z(n)).
SEND_DATA: Desde el BACKEND se enviaran los escenarios de batalla,
ejemplo: (-target.description-(x(n), y(n), z(n))) este es un ejemplo sencillo
ya que se trata de un solo objetivo estatico.

A combat experience based on Augmented Reality; the server acquires data 
(positions: x(n), y(n), z(n)) from the battlefield and returns battlefield 
scenarios (enemies that appears in certain positions (i-x(n), j-y(n), k-z(n)) 
wich are rendered by the AR-AR rifle) in wich the user should eliminate pressing 
the trigger in the AR-AR rifle.

