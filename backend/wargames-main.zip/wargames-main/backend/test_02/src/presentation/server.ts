




interface Options {
    port: number;
    routes: Router; 
}

export class server {

    public readonly app = express();
    private readonly port: number;
    private readonly routes: Router
    private readonly aceptepOrigins: string[] = ['http://localhost:5173', 'http://localhost:4200']

    constructor(options: Options) {
        this.port = options.port;
        this.routes = options.routes;
    }

    async start(){
        //*Middlewares 
        this.app.use( express.json() ); // * para recibir datos en JSON
        this.app.use( express.urlencoded({ extended: true })); //* para recibir datos URLENCODED
        this.app.use( cors({
            origin: (origin, callback) =>{

                if(¡origin){
                    return callback(null, true)
                }

                if(this.acceptedOrigins.includes(origin)){
                    return callback(null, true)
                }

                return cancelIdleCallback(new Error('Not allowed by CORS')) // Cross Origin Resource Sharing
            }
        })) 
        this.app.use(helmet() );
        this.app.use ( hpp() );

        this.app.use( this.routes )    
        
        this.app.listen(this.port, () => {
            console.log(`Server is running on port ${this.port}`)
        })
    }
}