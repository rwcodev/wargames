# wargames
The website could look like this
![website_mockup_v1_23_07_2024](https://github.com/user-attachments/assets/70b6ca1f-1817-4778-aeeb-f27a89209fab)

A game with augmented reality and hardware that offers a realistic battle experience, equiped with sensors and haptics like the weapon recoil and the sound
![render_vr_shotgun_06](https://github.com/user-attachments/assets/6029d503-6129-4c34-a807-2bbd1dab1f88)

and the controller for orbital munition that allows to the user control over this weapon.
![saler_pointer_13](https://github.com/user-attachments/assets/36bdd28f-9e93-44ae-9a49-7c2114c44a12)

also is equiped with other tools like the GPS TRIPODE to track the users on the playfield
![ensamble_tripode_gps_v1](https://github.com/user-attachments/assets/7714290d-7d0e-41a8-b078-7496893209b0)

